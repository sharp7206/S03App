# How does Babel versioning work?

## Does Babel follow semver?

Yes.
