The [AST specification](https://github.com/babel/babylon/blob/master/ast/spec.md) has been moved to the Babylon repo, `babel/babylon`.
