// comment
print("hello");

// comment2
print("hello2");
