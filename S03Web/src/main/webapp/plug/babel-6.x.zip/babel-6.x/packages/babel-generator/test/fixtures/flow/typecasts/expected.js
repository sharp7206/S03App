(xxx: number);
({ xxx: 0, yyy: "hey" }: { xxx: number; yyy: string; });
(xxx => xxx + 1: (xxx: number) => number);
(xxx: number), (yyy: string);
