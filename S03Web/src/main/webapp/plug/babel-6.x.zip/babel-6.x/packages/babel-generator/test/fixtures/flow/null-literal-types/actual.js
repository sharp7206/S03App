var foo: null;
