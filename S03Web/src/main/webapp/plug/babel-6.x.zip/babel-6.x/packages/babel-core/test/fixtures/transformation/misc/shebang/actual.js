#!/usr/bin/env node

foobar();
