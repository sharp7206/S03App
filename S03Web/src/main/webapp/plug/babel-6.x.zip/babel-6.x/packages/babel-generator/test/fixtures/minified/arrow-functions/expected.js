var foo=(arg1,arg2)=>{arg1;arg2};var foo2=(arg1,arg2)=>{arg1};var foo3=arg1=>arg1;
