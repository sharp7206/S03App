export default (function () {})();
