(function() {
  return;  // comment
}());
