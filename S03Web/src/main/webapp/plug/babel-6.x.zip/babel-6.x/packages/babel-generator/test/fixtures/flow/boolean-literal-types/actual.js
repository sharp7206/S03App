var foo: true;
var bar: false;
