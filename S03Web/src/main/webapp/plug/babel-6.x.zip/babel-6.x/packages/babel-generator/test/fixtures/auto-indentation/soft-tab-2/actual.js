function foo() {
  bar();
  if (foo) {
    bar();
  }
}
