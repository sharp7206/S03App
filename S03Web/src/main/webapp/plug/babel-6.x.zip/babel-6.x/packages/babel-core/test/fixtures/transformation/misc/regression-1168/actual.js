function test(x: string = "hi"): string {
  return x;
}
