function foo() {
  var x = 1;
  y();
  if (bar) {
    baz();
  }
  return;
}

function bar() {
    for(;;);
}
