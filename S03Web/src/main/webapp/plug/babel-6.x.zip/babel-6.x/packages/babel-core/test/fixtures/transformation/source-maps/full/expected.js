arr.map(function (x) {
  return x * x;
});
