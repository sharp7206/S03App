"use strict";

arr.map(function (x) {
  return x * MULTIPLIER;
});
