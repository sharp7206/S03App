const bug = 1;

function foo() {}

function bar() {
  var bug;
  bug = 2;
}
