arr.map(x => x * MULTIPLIER);
