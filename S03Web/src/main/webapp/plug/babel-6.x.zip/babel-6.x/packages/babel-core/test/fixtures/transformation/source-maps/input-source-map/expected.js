var foo = function () {
  return 4;
};
