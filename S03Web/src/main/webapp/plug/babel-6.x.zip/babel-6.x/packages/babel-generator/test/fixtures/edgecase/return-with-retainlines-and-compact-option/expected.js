function foo(l){
return(

l);

}
