function foo(l) {
  return (
    // hi
    l
  );
}
