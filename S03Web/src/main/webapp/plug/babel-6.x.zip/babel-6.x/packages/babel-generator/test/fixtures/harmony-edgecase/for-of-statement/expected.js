function test() {
  for (var i of array) {}

  for (let i of array) {}
}
