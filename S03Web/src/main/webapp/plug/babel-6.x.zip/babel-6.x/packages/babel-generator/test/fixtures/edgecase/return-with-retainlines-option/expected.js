function foo(l) {
  return (
    l);

}

function foo() {
  return (
    1 && 2 ||
    3);
}
