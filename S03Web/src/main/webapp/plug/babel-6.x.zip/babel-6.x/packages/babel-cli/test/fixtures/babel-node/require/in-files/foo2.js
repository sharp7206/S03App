import "./bar2";
import "./not_node_modules";

var foo = () => console.log("foo");
foo();
