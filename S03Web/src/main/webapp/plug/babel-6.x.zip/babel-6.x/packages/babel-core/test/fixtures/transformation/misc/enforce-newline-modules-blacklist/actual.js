export function foo() {}

export function bar() {}
