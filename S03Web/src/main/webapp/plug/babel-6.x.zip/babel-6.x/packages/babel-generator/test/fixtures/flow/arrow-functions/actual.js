const bar1 = (x: number): string => {};
const bar2 = (x?) => {};
const bar3 = (x?: string) => {};
const bar4 = x => {};
const bar5 = (x): string => {};
const bar6 = (x: number) => {};
const bar7 = <T>(x) => {};
