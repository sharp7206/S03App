class Foo {
  bar(): this {
    return this;
  }
}
