// foo
bar();
