for ((a in b) ? a : b; i;);
for (function(){for(;;);} && (a in b);;);
