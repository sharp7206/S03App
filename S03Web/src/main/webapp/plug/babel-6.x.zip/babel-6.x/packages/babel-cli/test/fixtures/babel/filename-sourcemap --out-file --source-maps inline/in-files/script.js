var foo = function () {
  return 4;
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yaWdpbmFsLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFVBQVUsWTtTQUFNLEM7Q0FBQyIsInNvdXJjZXNDb250ZW50IjpbInZhciBmb28gPSAoKSA9PiA0OyJdfQ==
