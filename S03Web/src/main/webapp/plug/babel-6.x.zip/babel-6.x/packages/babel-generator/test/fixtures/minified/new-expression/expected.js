new X;new Y()();new F().z;new new x();new new x()(a);new new x(a);new new x(a)(a);
