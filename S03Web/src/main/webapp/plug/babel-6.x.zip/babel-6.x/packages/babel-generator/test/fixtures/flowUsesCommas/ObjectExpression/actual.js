var a: { numVal: number };
var a: { numVal: number; };
var a: { numVal: number; [indexer: string]: number };
var a: ?{ numVal: number };
var a: { numVal: number; strVal: string }
var a: { subObj: {strVal: string} }
var a: { subObj: ?{strVal: string} }
var a: { param1: number; param2: string }
var a: { param1: number; param2?: string }
var a: { [a: number]: string; [b: number]: string; };
