if (true) {
  foo;
  bar2;
} else {
  foo;
  bar2;
}

function fn () {
  foo;
  bar2;
}
