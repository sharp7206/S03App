(function () {
  return; // comment
})();
