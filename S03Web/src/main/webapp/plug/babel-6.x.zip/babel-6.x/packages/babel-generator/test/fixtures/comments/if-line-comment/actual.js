function test() {
// Leading if statement
  if (cond) {print("hello") }
// Trailing if-block statement
}
