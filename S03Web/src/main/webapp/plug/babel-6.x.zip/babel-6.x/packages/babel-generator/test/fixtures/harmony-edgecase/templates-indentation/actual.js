function multilineTemplate() {
  return `I'm done reconfoobling
${ 'the energy motron' }
      ${'...or whatever'}`;
}

{
  const foo = `spam
and eggs!`;

  const bar = `${
    4 +
    2
  }`;

  const hello = `Hello
${ 'world' }`;
}
