import "foo";
import { foo } from "foo";
import { foo as bar } from "foo";
import { foo as bar, test as testing, logging } from "foo";
