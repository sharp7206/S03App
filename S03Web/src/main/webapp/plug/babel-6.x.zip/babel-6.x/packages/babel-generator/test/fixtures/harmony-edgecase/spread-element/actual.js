var [a, b, ...rest] = array;
const [a, b, ...rest] = array;
function a([a, b, ...rest]) {
}
([a, b, ...rest]) => { };
