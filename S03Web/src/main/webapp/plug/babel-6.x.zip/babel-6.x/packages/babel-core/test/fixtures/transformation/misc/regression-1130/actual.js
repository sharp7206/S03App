function A() {
  let a;
}

function B() {
  let a;
}
