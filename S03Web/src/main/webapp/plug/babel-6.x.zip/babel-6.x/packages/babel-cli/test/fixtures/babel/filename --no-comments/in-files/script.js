/*
 Test comment
 */

arr.map(x => x * MULTIPLIER);

// END OF FILE
