class A {
  prop1 = () => this;
  static prop2 = () => this;
  prop3 = () => arguments;
  static prop4 = () => arguments;
  prop5 = this;
  static prop6 = this;
  prop7 = arguments;
  static prop8 = arguments;
}
