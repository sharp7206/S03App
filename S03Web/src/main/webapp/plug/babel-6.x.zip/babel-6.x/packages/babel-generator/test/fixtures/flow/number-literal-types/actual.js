var a: 123;
var a: 123.0;
var a: 0x7B;
var a: 0b1111011;
var a: 0o173;
