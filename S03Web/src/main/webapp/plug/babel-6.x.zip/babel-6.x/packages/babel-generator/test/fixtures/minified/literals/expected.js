5;5;50;5e4;"foobar";" ";"\n\r";"\uD83D\uDE02";`😂`;/foobar/g;null;true;false;5;2;56;31;
