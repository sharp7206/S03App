// Leading to block
{
  print("hello");
}
