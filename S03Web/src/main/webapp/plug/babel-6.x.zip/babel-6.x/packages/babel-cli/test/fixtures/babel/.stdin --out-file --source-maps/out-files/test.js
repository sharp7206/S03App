"use strict";

arr.map(function (x) {
  return x * x;
});

//# sourceMappingURL=test.js.map
