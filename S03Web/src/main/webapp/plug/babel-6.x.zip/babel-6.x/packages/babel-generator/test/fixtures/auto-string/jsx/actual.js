var single = 'quotes';
var outnumber = 'double';
var moreSingleQuotesThanDouble = '!';

React.createClass({
  render() {
    return <View multiple="attributes" attribute="If parent is JSX keep double quote" />;
  }
});
