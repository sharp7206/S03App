module.exports = function () {
  throw new Error('Not a real preset');
}
