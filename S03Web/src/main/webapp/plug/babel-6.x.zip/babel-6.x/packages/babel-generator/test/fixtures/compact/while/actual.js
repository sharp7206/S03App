while(true) x();
