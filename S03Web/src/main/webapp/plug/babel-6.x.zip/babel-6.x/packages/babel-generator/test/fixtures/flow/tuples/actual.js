var a: [] = [];
var a: [Foo<T>] = [foo];
var a: [number,] = [123,];
var a: [number, string] = [123, "duck"];
