x = 1;
var { y = 1 } = obj;
