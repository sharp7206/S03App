var a: A.B;
var a: A.B.C;
var a: A.B<T>;
var a: typeof A.B<T>;
