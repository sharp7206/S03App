var foo = () => console.log("foo");
foo();
