"use strict";

var _values = values;
value = _values[fieldName];
rest = babelHelpers.objectWithoutProperties(_values, [fieldName]);

var error = void 0;