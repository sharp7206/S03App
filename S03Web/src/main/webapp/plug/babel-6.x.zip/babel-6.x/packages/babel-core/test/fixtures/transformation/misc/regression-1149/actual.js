function foo(bar) {
  var bar = bar[0];
}
