function a(p = 20) {}

function b(p, q = 30) {}

function c(p, q = 30, ...r) {}

(p = 20) => {};
(p = 20, ...q) => {};
