var test = {
  /**
   * Test 2
   */
  a: "1",
  /*
   * Test 1
   */
  b: "2",
  // Test 3
  c: "3"
};
