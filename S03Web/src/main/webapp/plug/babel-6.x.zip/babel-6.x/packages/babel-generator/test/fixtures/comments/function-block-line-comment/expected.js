!function () {} //
, 42;
!{ get 42() {} //
  , foo: 42 };
(function () {} //
);
