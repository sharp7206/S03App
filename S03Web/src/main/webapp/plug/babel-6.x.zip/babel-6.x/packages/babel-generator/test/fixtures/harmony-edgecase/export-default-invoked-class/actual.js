export default (class {})();
