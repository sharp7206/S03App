var bar = () => console.log("bar");
bar();
