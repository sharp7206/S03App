export default class Foo {}
