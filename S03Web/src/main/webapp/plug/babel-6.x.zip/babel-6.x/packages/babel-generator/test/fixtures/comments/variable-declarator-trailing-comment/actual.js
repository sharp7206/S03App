{
  var t = 20;  /*
                * This is trailing comment
                */
}

{
  var tt = 20; /*
                * This is trailing comment
                */
}
{{
  var t = 20; /*
               * This is trailing comment
               */
}}
