var a: number[];
var a: ?number[];
var a: (?number)[];
var a: () => number[];
var a: (() => number)[];
var a: typeof A[];
