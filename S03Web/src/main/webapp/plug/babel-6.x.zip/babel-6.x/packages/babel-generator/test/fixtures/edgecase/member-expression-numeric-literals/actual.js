1..toString;
2..toString();
0x1F7.toString();
0b111110111.toString();
0o767.toString();
