var a: { (): number };
var a: { (): number };
var a: { y: string; (): number; (x: string): string; };
var a: { <T>(x: T): number };
interface A { (): number };
