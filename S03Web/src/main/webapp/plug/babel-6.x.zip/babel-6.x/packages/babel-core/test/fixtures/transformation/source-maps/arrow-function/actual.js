var t = x => x * x;
