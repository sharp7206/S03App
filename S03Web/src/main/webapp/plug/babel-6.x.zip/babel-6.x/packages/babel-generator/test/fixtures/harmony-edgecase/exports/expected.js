export * from "OK";
export { name } from "OK";
export { a as b, c as d } from "hello";
export { a as e, c as f };
export {};
export default i = 20;
export function test() {}
export class test2 {}
export var j = 20;
export let k = 42;
