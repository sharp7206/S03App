do {} // LINE
while (true);
