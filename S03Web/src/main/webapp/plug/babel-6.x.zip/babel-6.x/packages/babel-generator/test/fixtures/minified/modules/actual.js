import * as foo from "foo";
import {foo as bar, foo2 as bar2} from "foo";
import {foo2} from "foo";

export * from "foo";
export {foo as bar} from "foo";
export {foo} from "foo";
