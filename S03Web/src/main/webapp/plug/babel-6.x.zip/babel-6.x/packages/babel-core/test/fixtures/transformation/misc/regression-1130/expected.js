function A() {
  var a = void 0;
}

function B() {
  var a = void 0;
}
