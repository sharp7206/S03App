module.exports = {
  plugins: [
    require('../../../../../babel-plugin-syntax-decorators'),
  ]
};
