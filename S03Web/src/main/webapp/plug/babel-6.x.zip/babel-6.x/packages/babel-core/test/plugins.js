import runner from "babel-helper-transform-fixture-test-runner";

runner(`${__dirname}/fixtures/plugins`, "plugins");
