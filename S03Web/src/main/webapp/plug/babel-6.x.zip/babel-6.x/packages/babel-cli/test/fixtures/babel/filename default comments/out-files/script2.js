"use strict";

/*
 Test comment
 */

arr.map(function (x) {
  return x * MULTIPLIER;
});

// END OF FILE
