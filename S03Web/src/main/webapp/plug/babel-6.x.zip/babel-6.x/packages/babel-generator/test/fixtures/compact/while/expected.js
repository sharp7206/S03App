while(true)x();
