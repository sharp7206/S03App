function createElement(tagName: "div"): HTMLDivElement {}
function createElement(tagName: 'div'): HTMLDivElement {}
