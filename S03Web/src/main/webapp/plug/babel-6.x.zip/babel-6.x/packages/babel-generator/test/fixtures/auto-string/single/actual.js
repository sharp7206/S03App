foo('foo');
foo('foo\nlol');
foo('foo\n"lol');
foo('foo\n"\'lol');
foo('😂');
