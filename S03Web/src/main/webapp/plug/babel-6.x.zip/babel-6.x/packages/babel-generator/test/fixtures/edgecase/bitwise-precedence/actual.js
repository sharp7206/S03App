x | y ^ z;
x | (y ^ z);
(x | y) ^ z;
