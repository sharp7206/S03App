function x() {
  return -1;
  return --i;
  return !2;
  return void 0;
}

throw -1;
