function f() {
  let g = async () => {
    this;
  };
};

class Class {
  async m() {
    var c = async (b) => {
      this
    }
  }
}
