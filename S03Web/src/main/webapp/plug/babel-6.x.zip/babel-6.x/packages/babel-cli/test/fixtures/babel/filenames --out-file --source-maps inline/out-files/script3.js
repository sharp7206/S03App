"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Test = function Test() {
  _classCallCheck(this, Test);
};
"use strict";

arr.map(function (x) {
  return x * MULTIPLIER;
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNjcmlwdC5qcyIsInNjcmlwdDIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztJQUFNLEk7Ozs7O0FDQU4sSUFBSSxHQUFKLENBQVE7QUFBQSxTQUFLLElBQUksVUFBVDtBQUFBLENBQVIiLCJmaWxlIjoic2NyaXB0My5qcyIsInNvdXJjZXNDb250ZW50IjpbImNsYXNzIFRlc3Qge1xuXG59IiwiYXJyLm1hcCh4ID0+IHggKiBNVUxUSVBMSUVSKTsiXX0=
