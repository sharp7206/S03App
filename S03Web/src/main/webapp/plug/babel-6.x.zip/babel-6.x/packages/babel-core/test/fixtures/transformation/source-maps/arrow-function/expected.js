var t = function t(x) {
  return x * x;
};
