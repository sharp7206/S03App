var test = {
  /**
   * Before bracket init
   */
  ["a"]: "1",
  [/*
    * Inside bracket init
    */
  "b"]: "2"
},
    ok = 42;
